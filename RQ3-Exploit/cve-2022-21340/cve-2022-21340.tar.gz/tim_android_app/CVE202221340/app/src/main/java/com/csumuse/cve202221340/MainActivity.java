package com.csumuse.cve202221340;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;


import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.StrictMode;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


import java.util.Arrays;
import java.util.Map;
import java.util.jar.Attributes;
import java.util.jar.JarFile;

import java.io.File;

public class MainActivity extends Activity implements  View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.starter);
            //super(R.layout.starter);



        Button launchButton=findViewById(R.id.launch_button);
        launchButton.setOnClickListener(
                this::onClick
        );

    }

    @Override
    public void onClick(View v) {
        if (v == (Button) findViewById(R.id.launch_button)) {
            try{

                launch_hang("sampledata/test.jar");
            } catch (Exception e) {
                e.printStackTrace();
                TextView logView=(TextView) findViewById(R.id.logsView);
                String logText="Exception:"+ e +"\n";
                logView.setText(logText);
            }

        }
    }


        public void launch_hang(String file_path) throws Exception {

            //launch toast
            Toast.makeText(this, "Launching hang attempt", Toast.LENGTH_SHORT).show();

            //def samplesDir = new File(projectDir.absolutePath, "sampledata")


            // a line in a jar manifest is max 512 bytes
            // all lines with space and single letters

            File file = new File(this.getFilesDir(), file_path);
            TextView debugView=(TextView) findViewById(R.id.debug);

            String path = Environment.getExternalStorageDirectory().toString()+"/Pictures";
            String debugMessage=( "Path: " + path+"\n");
            debugView.setText(debugMessage);

            //

            File directory = new File(path);//+ "/Documents/");
            File[] files = directory.listFiles();
            if (files != null) {
                debugMessage += "List Files: " + String.valueOf(files.length) + "\n";
                debugView.setText(debugMessage);
                for (File indiv_file : files){
                    debugMessage+=indiv_file.getName()+"\n";
                    debugView.setText(debugMessage);
                }
            }else {
                debugMessage += "List Files: null \n" ;
                debugView.setText(debugMessage);
            }

            //Former version:
            //debugMessage+= "List Files: "+ Arrays.stream(files).toArray().toString() +"\n";
            //debugView.setText(debugMessage);

            String target_jar_path = "/storage/emulated/0/Documents/test.png";

            TextView logView=(TextView) findViewById(R.id.logsView);
            String logText="Log:\n";
            logView.setText(logText);

            // printHeapInfo();
            //System.out.println("start reading jar..."+TARGET_JAR);
            logText+="start reading jar..."+target_jar_path+"\n";
            logView.setText(logText);
            Log.d("openJar","Starting Jar reading");
            java.util.jar.JarFile jf = new JarFile(target_jar_path);
            Map<String, Attributes> e2a = jf.getManifest().getEntries();
            Attributes ma = jf.getManifest().getMainAttributes();
            String v = ma.getValue("a1000");
            //System.out.println("value for a0: " + v);
            logText+="value for a0: " + v;
            logView.setText(logText);
            //System.out.println("entries: "+ e2a.keySet().size());
            logText+="entries: "+ e2a.keySet().size()+"\n";
            logView.setText(logText);

            for (String s: e2a.keySet()) {
                //System.out.println("key: "+ s);
                logText+="key: "+ s+"\n";
                logView.setText(logText);

            }
            //System.out.println("end reading jar...");
            logText+="end reading jar..."+"\n";
            logView.setText(logText);

    }



}
